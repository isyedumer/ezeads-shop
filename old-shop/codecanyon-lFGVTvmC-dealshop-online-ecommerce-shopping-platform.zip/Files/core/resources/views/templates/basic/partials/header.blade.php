@include($activeTemplate.'partials.header.header_top')
@include($activeTemplate.'partials.header.header_bottom')
@include($activeTemplate.'partials.header.header_menu')