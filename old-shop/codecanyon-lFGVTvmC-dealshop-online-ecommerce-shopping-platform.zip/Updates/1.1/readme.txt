HOW TO UPDATE :

Please just upload the file "Update.zip" into the main dir of your server.

Changes We made :

[PATCH] Dynamic SEO contents for product sharing on social media sites.
